package com.example.crud

class Estado {
    companion object{
        const val NOTIFICADO=0
        const val CREADO=1
        const val MODIFICADO=2
    }
}